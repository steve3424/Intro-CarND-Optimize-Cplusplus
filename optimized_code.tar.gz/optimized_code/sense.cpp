#include "headers/sense.h"

using namespace std;

// OPTIMIZATION: Pass larger variables by reference
vector< vector <float> > sense(char color, vector< vector <char> > &grid, vector< vector <float> > &beliefs,  float p_hit, float p_miss) {
	int i, j, height, width;
	height = grid.size();
	width = grid.size();

	for (i=0; i<height; i++) {
		for (j=0; j<width; j++) {
          	bool hit = grid[i][j] == color;
          	beliefs[i][j] *= (p_hit*hit + (1-hit)*p_miss);
		}
	}
	return beliefs;
}
