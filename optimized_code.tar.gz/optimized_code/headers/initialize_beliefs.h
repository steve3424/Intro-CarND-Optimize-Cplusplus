#ifndef INITIALIZE_BELIEFS_H
#define INITIALIZE_BELIEFS_H

#include <vector>

std::vector< std::vector <float> > initialize_beliefs(std::vector< std::vector <char> > &grid);

#endif /* INITIALIZE_BELIEFS.H */
