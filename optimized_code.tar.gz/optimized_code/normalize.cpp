#include "headers/normalize.h"
using namespace std;

// OPTIMIZATION: Pass variable by reference
vector< vector<float> > normalize(vector< vector <float> > &grid) {

  	int height = grid.size();
  	int width = grid[0].size();
  	float total = 0.0;
	int i;
	int j;
  
  	// get total
	for (i = 0; i < height; i++) {
		for (j=0; j< width; j++) {
        	total += grid[i][j];
		}
	}

  	// normalize each cell
	for (i = 0; i < height; i++) {
		for (j=0; j< width; j++) {
        	grid[i][j] /= total;
		}
	}

	return grid;
}
