#include "headers/blur.h"
#include "headers/zeros.h"

using namespace std;

vector < vector <float> > blur(vector < vector < float> > &grid, float blurring) {
  	// initialize newGrid
  	int height = grid.size();
	int width = grid[0].size();
  	vector < vector <float> > newGrid = zeros(height, width);

	// calculate blur factors
	float center = 1.0 - blurring;
	float corner = blurring / 12.0;
	float adjacent = blurring / 6.0;
  	
  	static vector < vector <float> > window = {{corner, adjacent, corner}, 
                                        {adjacent, center, adjacent}, 
                                        {corner, adjacent, corner}};
  	
  	//static vector <int> DX = {-1, 0, 1};
	//static vector <int> DY = {-1, 0, 1};

  	// variables for blur
	//int dx;
	//int dy;
  	int i;
  	int j;
	int ii;
	int jj;
	int new_i;
	int new_j;
	float multiplier;
  	float val;

	// blur the grid and store in a new 2D vector
	for (i=0; i< height; ++i ) {
		for (j=0; j<width; ++j ) {
			val = grid[i][j];
			for (ii=-1; ii<2; ++ii) {
              	//dy = DY[ii];
				for (jj=-1; jj<2; ++jj) {
                  	//dx = DX[jj];
					new_i = (i + ii + height) % height;
					new_j = (j + jj + width) % width;
					multiplier = window[ii+1][jj+1];
					newGrid[new_i][new_j] += val * multiplier;
				}
			}
		}
	}

	return newGrid;
}
