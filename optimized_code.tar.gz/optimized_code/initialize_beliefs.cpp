#include "headers/initialize_beliefs.h"

using namespace std;

// OPTIMIZATION: pass large variables by reference
vector< vector <float> > initialize_beliefs(vector< vector <char> > &grid) {
  	// initialize variables for new grid
	int height = grid.size();
  	int width = grid[0].size();

  	// calculate the probability per cell -- this in an intermediary variable, but it doesn't seem to affect the speed much and makes it more readable I think
  	float prob_per_cell = 1.0 / height * width;
  	// initialize newGrid with prob_per_cell
  	vector < vector <float> > newGrid(height, vector <float>(width, prob_per_cell));
  
	return newGrid;
}